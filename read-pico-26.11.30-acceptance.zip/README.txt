ReadPico / pico-plus · 30 批步 4/5 验收发布包（acceptance）
================================================================
批次      : 伴读案 30 批 步 4/5 收尾
固件版本  : 0.3.9-pico26.11.30
APK 版本  : 1.6.6 (versionCode 18)

发布实体（15:40 §五 补裁）
  Read_Pico-26.11.30-0418a6aa.bin   4385920 B  sha256 0418a6aad983f27d6ab251753f6f0b469b6de53a98538e67770bd1f30a40e11b
  ReadPicoPush-v1.6.6-d5ca0e71.apk   70169 B  sha256 d5ca0e714b681260dafb2fdd4fb2f7786f779a3b8c816569c908d4de28b6337a
固件件为 65a1dc3b A 组修复测试件同源升版串重编译正式件：功能二进制等同、
仅版本串注入差异（67 字节 3 簇，代码段零差异）。APK 件为步 5 交付候选件
（FEED_URL 提案值 + bump 18/1.6.6）。65a1dc3b 与 e1d70d38 保持测试件身份，
不升格、不入包；34a39db5（4,378,272 B 无伴读模式历史正式件）退役为历史序列，
严禁作本轮发布实体，本包不含该件。

包内清单
  Read_Pico-26.11.30-0418a6aa.bin   固件正式件
  ReadPicoPush-v1.6.6-d5ca0e71.apk   APK 交付候选件
  apk-update.json  正式 feed（versionCode 18，与发布面同批上 pico-plus 根）
  README.txt       本说明
  SHA256SUMS       包内四件校验和（不含 zip 自身）

现场收尾自检（发布后，不预填结果）
  交付候选件冒烟三查：检查失败＝预期通过 / 连接即校时 / 伴读主链一条
  公主发布验收：刷正式件开机 + 版本串确认 + 伴读一条
